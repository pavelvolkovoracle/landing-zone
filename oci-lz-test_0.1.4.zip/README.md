# OCI Test Landingzone Package

This is a test landingzone package for use in testing the
OCI Launchpad service. 

 
