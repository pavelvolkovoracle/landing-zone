# Release Notes

## v0.1.4 - 2024-01-11
- Added additional outputs for extension testing

## v0.1.3 - 2023-12-20

- Added testing delay before creating first bucket. Controlled by same compartment_replication_delay var as before to avoid adding new variable. 

## v0.1.2 - 2023-11-16

- Added new test bucket to test version changes
- Added release notes

## v0.1.1 - 2023-09-05

- Simple test package
- Added compartment to create test resources under
- Added new inputs
- Changed resources to buckets as they are easy to create/destroy.